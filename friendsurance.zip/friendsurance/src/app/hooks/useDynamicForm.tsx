import {Form, Input, Select, Radio, Checkbox, DatePicker, Button, Space, CheckboxOptionType, InputNumber, } from 'antd';
import { IQuestionData } from '../types';

interface IForm extends IQuestionData {
    onSubmit?: (valeus: object) => void;
    type: string;
}

interface IOption{
    value?: string | number | boolean | undefined;
    label: string;
}

const FormItem = Form.Item;

export const useDynamicForm = ({ onSubmit, type, id, options, validations }: IForm) => {
  const [form] = Form.useForm();
  const getRelatedComponent = (type: string, options?: IOption[]) => {
    switch (type) {
      case 'TEXT':
        return <Input />;
      case 'NUMBER':
        return <Input type="number"/>;
      case 'SELECT':
        return <Select options={options} />;
      case 'RADIO':
        return <Radio.Group options={options as CheckboxOptionType[]} />;
      case 'CHECKBOX':
        return (
          <Checkbox.Group
            options={options as CheckboxOptionType[]}
          />
        );
      case 'DATE':
        return <DatePicker />;
      default:
        return <Input />;
    }
  };

  const onCancel = () => {
    form.resetFields();
  };

  const renderForm = (value:any) => {
    return (
      <Form onFinish={onSubmit} form={form} initialValues={{
        [id]: value
      }}>
        <FormItem
          name={id}
          rules={[{ required: true, message: 'Field is required' }].concat(
            validations?.map(i=>({ ...i,required:true})) || []
          )}
        >
          {getRelatedComponent(type, options)}
        </FormItem>
        <Space>
          <Button type="link" onClick={onCancel}>
            Cancel
          </Button>
          <Button htmlType="submit" type="primary">
            Submit
          </Button>
        </Space>
      </Form>
    );
  };

  return {
    renderForm,
  };
};