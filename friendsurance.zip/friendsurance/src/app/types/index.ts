/* eslint-disable @typescript-eslint/no-explicit-any */
export interface IQuestionData {
  id: string;
  title: string;
  type: string;
  description: string;
  options: IOption[];
  enabled: boolean | string;
  answer?: string;
  validations?: IValidation[];
}

export interface IOption {
  value: string;
  label: string;
}


export interface IValidation {
  type: string;
  message: string;
  min?: number;
  max?: number;
}

export interface IEvent {
  [key:string]: (...args: any[]) => any;
}
export interface IData {
  [key:string]: any;
  
}
export interface IController {
  events: IEvent;
  data: IData;
}