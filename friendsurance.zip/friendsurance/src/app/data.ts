import { IQuestionData } from "./types";

const questions : IQuestionData[] = [
  {
    "id": "QUESTION_1",
    "title": "What is your name?",
    "description": "a paragraph of random text...!",
    "type": "label",
    "options": [],
    "enabled": true,
    "validations": [
      { "type": "string","min":3, "message": "Your name must not be shorter than 3 characters." },
      { "type": "string", "max": 25, "message": "Your name must not be longer than 25 characters." }
    ]
  },
  {
    "id": "QUESTION_2",
    "title": "What is your gender?",
    "description": "a paragraph of random text...!",
    "type": "RADIO",
    "options": [
      { "value": "FEMALE", "label": "Female" },
      { "value": "MALE", "label": "Male" },
      { "value": "OTHER", "label": "Other" }
    ],
    "enabled": true,
    "validations": []
  },
  {
    "id": "QUESTION_3",
    "title": "What is your the date of your birth?",
    "description": "a paragraph of random text...!",
    "type": "DATE",
    "options": [],
    "enabled": "QUESTION_2 != \"OTHER\"",
    "validations": []
  },
  {
    "id": "QUESTION_4",
    "title": "What insurances do you have?",
    "description": "a paragraph of random text...!",
    "type": "CHECKBOX",
    "options": [
      { "value": "HEALTH", "label": "Health" },
      { "value": "LIABILITY", "label": "Liability" },
      { "value": "LEGAL", "label": "Legal" },
      { "value": "CAR", "label": "Car" }
    ],
    "enabled": true,
    "validations": []
  },
  {
    "id": "QUESTION_5",
    "title": "What is your employment status?",
    "description": "a paragraph of random text...!",
    "type": "SELECT",
    "options": [
      { "value": "EMPLOYEE", "label": "Employee" },
      { "value": "BUSINESS_OWNER", "label": "Business Owner" },
      { "value": "HOUSE_SPOUSE", "label": "Housewife / Househusband" },
      { "value": "RETIREE", "label": "Retiree" },
      { "value": "STUDENT", "label": "Student" },
      { "value": "SELF_EMPLOYED", "label": "Self-Employed" },
      { "value": "UNEMPLOYED", "label": "Unemployed" }
    ],
    "enabled": true,
    "validations": []
  },
  {
    "id": "QUESTION_6",
    "title": "What is your phone number?",
    "description": "a paragraph of random text...!",
    "type": "NUMBER",
    "options": [],
    "enabled": "QUESTION_5 == \"EMPLOYEE\" || QUESTION_5 == \"BUSINESS_OWNER\" || QUESTION_5 == \"STUDENT\"",
    "validations": [
      { "type": "string","min": 7,"message": "Your number must be only digits and not shorter than 7." },
      { "type": "string","max": 12,"message": "Your number must be only digits and not longer than 12." },
    ]
  }
]
export default questions;