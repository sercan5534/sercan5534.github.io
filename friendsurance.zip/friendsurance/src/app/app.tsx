import styled from 'styled-components';
import QuestionnaireForm from './components/questionnaire-form';
import questions from './data';
const Wrapper = styled.div`
  // Your style here
`;

export function App() {
  return (
    <Wrapper>
      <QuestionnaireForm questions={questions}></QuestionnaireForm>
    </Wrapper>
  );
}

export default App;
