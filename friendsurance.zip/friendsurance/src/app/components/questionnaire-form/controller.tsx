import React, { useCallback, useMemo, useState } from 'react';
import { IController } from '../../types';
import { IQuestionnaireFormProps } from './interfaces';
import { on } from 'events';

interface IAnswer {
  [key: string]: string | number | boolean | undefined;
}

interface IState {
  answers: IAnswer;
  expandedQuestionIndex: number;
  currenntlyExpandedQuestionId: string;
  counter: number;
}

export const useController = ({questions}:IQuestionnaireFormProps): IController => {
  const [state, setState] = useState<IState>({
    answers: {},
    expandedQuestionIndex: 0,
    counter: 0,
    currenntlyExpandedQuestionId: questions[0].id,
  });

  const onSetState = (obj: object) => {
    setState({ ...state, ...obj });
  };

  const generateRandomStr = (): string => {
    return Math.random().toString(36).substring(2, 15);
  };
  
  //generate a random prefix for the form item
  //to clear on reset
  const keyPrefix = useMemo(() => {
    return `questionnaire-form-${generateRandomStr()}`;
  }, [state.counter]);

  const answeredQuestions = useMemo(() => {
    return Object.keys(state.answers);
  }, [state.answers]);
  const questionKeys = useMemo(() => {
    return questions.map(i=>i.id);
  }, [questions]);

  const evalInObj = (code:string,context: object) : boolean => {
    // eslint-disable-next-line no-eval
    const result = eval(
      `(function random(){ for(let i in this){ window[i] = this[i]; } return ${code} })`
    ).call(context);
    return result;
  }
  
  const visibleQuestions = useMemo(() => {
    let ques = [questions[0]];
    if (answeredQuestions.length > 0) {
      ques = [
        ...ques,
        ...questions.filter((q) => {
          return answeredQuestions.includes(q.id) && ques.indexOf(q) === -1;
        }),
      ];
    }
    if (
      state.expandedQuestionIndex !== 0 && state.expandedQuestionIndex < questions.length
    ) {
      //next question with case
      const nextQuestion = questions[state.expandedQuestionIndex];
      if(answeredQuestions.includes(nextQuestion.id)){
        onSetState({
          currenntlyExpandedQuestionId : questions[state.expandedQuestionIndex].id
        });
      }
      else if (
        nextQuestion.enabled === true ||
        (typeof nextQuestion.enabled === 'string' &&
          evalInObj(nextQuestion.enabled, state.answers))
      ) {
        ques.push(nextQuestion);
      } else if (state.expandedQuestionIndex + 1 < questions.length) {
        onSetState({
          expandedQuestionIndex: state.expandedQuestionIndex + 1,
          currenntlyExpandedQuestionId : questions[state.expandedQuestionIndex + 1].id,
        });
      } else {
        console.log('No more questions');
      }
    }
    return ques;
  }, [answeredQuestions,state.expandedQuestionIndex]);
  

  const onClear = (): void => {
    onSetState({
      answers: {},
      counter: state.counter + 1,
      expandedQuestionIndex: 0,
      currenntlyExpandedQuestionId: questions[0].id,
    });
  };

  const onSubmit = (values:object): void => {
    const nextQuestion = questions[state.expandedQuestionIndex + 1];
    onSetState({
      answers: { ...state.answers, ...values },
      expandedQuestionIndex: state.expandedQuestionIndex + 1,
      currenntlyExpandedQuestionId: nextQuestion ?  nextQuestion.id : "completed",
    });
  };

  const onCancel = (id: string): void => {
    console.log('Cancel');
  };
  const onExpand = (id: string): void => {
    onSetState({
      currenntlyExpandedQuestionId: id,
      expandedQuestionIndex: questionKeys.indexOf(id),
    });
  };

  return {
    events: { onClear, onSubmit, onCancel, onExpand },
    data: {
      answers: state.answers,
      expandedQuestionIndex: state.expandedQuestionIndex,
      currenntlyExpandedQuestionId: state.currenntlyExpandedQuestionId,
      questions: visibleQuestions,
      keyPrefix,
    },
  };
};
