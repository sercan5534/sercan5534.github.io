import { IQuestionData } from "../../types";

export interface IQuestionnaireFormProps {
  questions: IQuestionData[];
}