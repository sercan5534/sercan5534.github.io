import styled from "styled-components";

export const FormContainer = styled.div`
  padding: 16px;
`;
FormContainer.displayName = "FormContainer";
