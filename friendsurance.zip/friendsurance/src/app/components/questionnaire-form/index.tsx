import React, { useState } from "react";
import Question from "../question";
import { IQuestionnaireFormProps } from "./interfaces";
import { FormContainer } from "./elements";
import { useController } from "./controller";
import { IQuestionData } from "src/app/types";
import { Button } from "antd";

const QuestionnaireForm: React.FC<IQuestionnaireFormProps> = (props) => {
  const {
    events: { onClear, onSubmit, onCancel, onExpand },
    data: { answers, questions, keyPrefix, currenntlyExpandedQuestionId },
  } = useController(props);

  return (
    <FormContainer>
      {(questions as IQuestionData[]).map((question) => (
        <Question
          key={`${keyPrefix}-${question.id}`}
          question={question}
          answer={answers[question.id]}
          onAnswer={onSubmit}
          onExpand={onExpand}
          onCancel={onCancel}
          isExpanded={currenntlyExpandedQuestionId === question.id}
          
        />
      ))}
      <Button onClick={onClear}>Clear</Button>
    </FormContainer>
  );
};

export default QuestionnaireForm;
