import React, { Fragment, memo, useState } from 'react';
import { IQuestionData } from '../../types';
import { QuestionAnswer, QuestionContainer, QuestionDescription, QuestionTitle } from './elements';
import { useDynamicForm } from 'src/app/hooks/useDynamicForm';
import { Button } from 'antd';

type IQuestionProps = {
  question: IQuestionData;
  answer?: any;
  onAnswer: (values: object) => void;
  onCancel: (id: string) => void;
  onExpand: (id: string) => void;
  isExpanded?: boolean;
};

const Question: React.FC<IQuestionProps> = memo(
  ({ question, onAnswer, onCancel, onExpand, answer, isExpanded = false }) => {
    const { renderForm } = useDynamicForm({
      onSubmit: onAnswer,
      ...question,
    });
    return (
      <QuestionContainer>
        <QuestionTitle>{question.title} </QuestionTitle>
        {!isExpanded ? (
          <Fragment>
            <QuestionAnswer>{question.id === "QUESTION_3" ? answer?.format("DD.MM.YYYY") : answer} </QuestionAnswer>
            <Button type="link" onClick={() => onExpand(question.id)}>
              Edit
            </Button>
          </Fragment>
        ) : (
          <Fragment>
            <QuestionDescription>{question.description}</QuestionDescription>
            {renderForm(answer)}
          </Fragment>
        )}
      </QuestionContainer>
    );
  },
  (prevProps, newProps) => {
    return (
      prevProps.isExpanded === newProps.isExpanded &&
      prevProps.answer === newProps.answer
    );
  }
);

export default Question;
