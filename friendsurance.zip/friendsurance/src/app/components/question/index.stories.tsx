import type { Meta } from '@storybook/react';
import Question from './index';

const Story: Meta<typeof Question> = {
  component: Question,
  title: 'Components/Question',
};
export default Story;

export const Default = {
  args: {
    question: {
      title: 'Question',
      description: 'This is a question',
      id: 'QUESTION_1',
      type: 'TEXT',
    },
    answer: 'Answer',
    isExpanded: true
  },
};
