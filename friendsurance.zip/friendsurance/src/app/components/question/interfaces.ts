import { IQuestionData } from "src/app/types";

export interface IQuestionProps  extends IQuestionData{
  answer: string | undefined;
  onAnswer: (questionId: string, answer: string) => void;
}
