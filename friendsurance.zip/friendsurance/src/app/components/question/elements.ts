import styled from "styled-components";

export const QuestionContainer = styled.div`
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 16px;
  margin-bottom: 16px;
`;

export const QuestionTitle = styled.h3`
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 8px;
`;
export const QuestionAnswer = styled.h5`
  font-size: 12px;
  font-weight: italix;
  margin-bottom: 8px;
`;

export const QuestionDescription = styled.p`
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
`;
