import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import Question from './index';

//workaround for jest and matchMedia
//https://jestjs.io/docs/manual-mocks#mocking-methods-which-are-not-implemented-in-jsdom
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // Deprecated
    removeListener: jest.fn(), // Deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});

describe('Question', () => {
  const question = {
    id: 'QUESTION_1',
    title: 'Question 1',
    description: 'Description 1',
    type: 'TEXT',
    enabled: true,
    options: [],
  };

  const answer = 'Answer 1';
  const onAnswer = jest.fn();
  const onCancel = jest.fn();
  const onExpand = jest.fn();

  it('should render the question title', () => {
    const { getByText } = render(
      <Question
        question={question}
        onAnswer={onAnswer}
        onCancel={onCancel}
        onExpand={onExpand}
      />
    );
    const titleElement = getByText('Question 1');
    expect(titleElement).toBeInTheDocument();
  });

  it('should render the answer when not expanded', () => {
    const { getByText } = render(
      <Question
        question={question}
        onAnswer={onAnswer}
        onCancel={onCancel}
        onExpand={onExpand}
        answer={answer}
      />
    );
    const answerElement = getByText('Answer 1');
    expect(answerElement).toBeInTheDocument();
  });

  it('should call onExpand when Edit button is clicked', () => {
    const { getByText } = render(
      <Question
        question={question}
        onAnswer={onAnswer}
        onCancel={onCancel}
        onExpand={onExpand}
      />
    );
    const editButton = getByText('Edit');
    fireEvent.click(editButton);
    expect(onExpand).toHaveBeenCalledTimes(1);
    expect(onExpand).toHaveBeenCalledWith('QUESTION_1');
  });

  /* it('should call onAnswer when form is submitted', () => {
    const { getByLabelText, getByText } = render(
      <Question
        question={question}
        onAnswer={onAnswer}
        onCancel={onCancel}
        onExpand={onExpand}
        isExpanded={true}
      />
    );
    const inputElement = getByText('Question 1');
    fireEvent.change(inputElement, { target: { value: 'New Answer' } });
    const submitButton = getByText('Submit');
    fireEvent.click(submitButton);
    expect(onAnswer).toHaveBeenCalledTimes(1);
    expect(onAnswer).toHaveBeenCalledWith('New Answer');
  }); */

});
